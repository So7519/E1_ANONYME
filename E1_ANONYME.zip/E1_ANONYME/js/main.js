const API_PROJECTS = "https://webcraft-api.vercel.app/data/projects.json";
const API_COURSES = "https://webcraft-api.vercel.app/data/courses.json";

let projectsData = [];
let coursesData = [];

document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("projects-grid")) {
        fetchProjects();
        fetchCourses();
        setupModal();
    }

    if (document.getElementById("registration-form")) {
        loadCoursesInSelect();
        setupFormValidation();
    }
});

async function fetchProjects() {
    const loader = document.getElementById("projects-loader");
    const errorMsg = document.getElementById("projects-error");

    try {
        const response = await fetch(API_PROJECTS);
        const data = await response.json();

        projectsData = data.projects;

        fillSelect("project-tech", data.technologies);
        fillSelect("project-category", data.categories);

        displayProjects(projectsData);

        document.getElementById("project-search").addEventListener("input", filterProjects);
        document.getElementById("project-tech").addEventListener("change", filterProjects);
        document.getElementById("project-category").addEventListener("change", filterProjects);

    } catch (error) {
        errorMsg.classList.remove("hidden");
    } finally {
        loader.classList.add("hidden");
    }
}

function displayProjects(projects) {
    const grid = document.getElementById("projects-grid");
    grid.innerHTML = "";

    if (projects.length === 0) {
        grid.innerHTML = "<p>Aucun projet trouvé.</p>";
        return;
    }

    projects.forEach((project) => {
        const card = document.createElement("article");
        card.className = "card";

        const badgesHtml = project.technologies
            .map((tech) => `<span class="badge">${tech}</span>`)
            .join("");

        card.innerHTML = `
            <img src="${project.image}" alt="${project.title}">
            <div class="card-body">
                <h3>${project.title}</h3>
                <p><strong>Client :</strong> ${project.client}</p>
                <p><strong>Catégorie :</strong> ${project.category}</p>
                <div class="badges">${badgesHtml}</div>
                <div class="card-actions">
                    <button type="button" class="btn">Voir détails</button>
                </div>
            </div>
        `;

        card.querySelector("button").addEventListener("click", () => openProjectModal(project));
        grid.appendChild(card);
    });
}

function filterProjects() {
    const search = document.getElementById("project-search").value.toLowerCase();
    const tech = document.getElementById("project-tech").value;
    const category = document.getElementById("project-category").value;

    const filtered = projectsData.filter((project) => {
        const matchSearch = project.title.toLowerCase().includes(search) || project.client.toLowerCase().includes(search);
        const matchTech = tech === "" || project.technologies.includes(tech);
        const matchCat = category === "" || project.category === category;

        return matchSearch && matchTech && matchCat;
    });

    displayProjects(filtered);
}

async function fetchCourses() {
    const loader = document.getElementById("courses-loader");
    const errorMsg = document.getElementById("courses-error");

    try {
        const response = await fetch(API_COURSES);
        const data = await response.json();

        coursesData = data.courses;

        fillSelect("course-category", data.categories);
        fillSelect("course-level", data.levels);
        fillSelect("course-tech", data.technologies);

        displayCourses(coursesData);

        document.getElementById("course-search").addEventListener("input", filterCourses);
        document.getElementById("course-category").addEventListener("change", filterCourses);
        document.getElementById("course-level").addEventListener("change", filterCourses);
        document.getElementById("course-tech").addEventListener("change", filterCourses);

    } catch (error) {
        errorMsg.classList.remove("hidden");
    } finally {
        loader.classList.add("hidden");
    }
}

function displayCourses(courses) {
    const grid = document.getElementById("courses-grid");
    grid.innerHTML = "";

    if (courses.length === 0) {
        grid.innerHTML = "<p>Aucune formation trouvée.</p>";
        return;
    }

    courses.forEach((course) => {
        const card = document.createElement("article");
        card.className = "card";

        const statusBadge = course.available
            ? `<span class="badge badge-dispo">Disponible</span>`
            : `<span class="badge badge-complet">Complet</span>`;

        const badgesHtml = course.technologies
            .map((tech) => `<span class="badge">${tech}</span>`)
            .join("");

        card.innerHTML = `
            <img src="${course.image}" alt="${course.title}">
            <div class="card-body">
                <div>${statusBadge} <span class="badge">${course.level}</span></div>
                <h3>${course.title}</h3>
                <p><strong>Catégorie :</strong> ${course.category}</p>
                <p><strong>Durée :</strong> ${course.duration} | <strong>Prix :</strong> ${course.price} €</p>
                <p><strong>Note :</strong> ${course.rating}/5 (${course.students} étudiants)</p>
                <div class="badges">${badgesHtml}</div>
                <div class="card-actions">
                    <button type="button" class="btn btn-secondary">Voir détails</button>
                    <a href="inscription.html" class="btn">S'inscrire</a>
                </div>
            </div>
        `;

        card.querySelector("button").addEventListener("click", () => openCourseModal(course));
        grid.appendChild(card);
    });
}

function filterCourses() {
    const search = document.getElementById("course-search").value.toLowerCase();
    const category = document.getElementById("course-category").value;
    const level = document.getElementById("course-level").value;
    const tech = document.getElementById("course-tech").value;

    const filtered = coursesData.filter((course) => {
        const matchSearch = course.title.toLowerCase().includes(search);
        const matchCat = category === "" || course.category === category;
        const matchLevel = level === "" || course.level === level;
        const matchTech = tech === "" || course.technologies.includes(tech);

        return matchSearch && matchCat && matchLevel && matchTech;
    });

    displayCourses(filtered);
}

function fillSelect(selectId, items) {
    const select = document.getElementById(selectId);
    if (!select || !items) return;

    items.forEach((item) => {
        const option = document.createElement("option");
        option.value = item;
        option.textContent = item;
        select.appendChild(option);
    });
}

function openProjectModal(project) {
    const modal = document.getElementById("modal");
    const body = document.getElementById("modal-body");

    const featuresHtml = (project.features || []).map((f) => `<li>${f}</li>`).join("");
    const techsHtml = project.technologies.join(", ");

    body.innerHTML = `
        <img src="${project.image}" alt="${project.title}">
        <h2 id="modal-title">${project.title}</h2>
        <p><strong>Client :</strong> ${project.client}</p>
        <p><strong>Catégorie :</strong> ${project.category}</p>
        <p><strong>Technologies :</strong> ${techsHtml}</p>
        <p>${project.description}</p>
        <h3>Fonctionnalités :</h3>
        <ul>${featuresHtml}</ul>
        <a href="${project.url}" target="_blank" class="btn">Voir le site du projet</a>
    `;

    modal.classList.remove("hidden");
}

function openCourseModal(course) {
    const modal = document.getElementById("modal");
    const body = document.getElementById("modal-body");

    const modulesHtml = (course.modules || []).map((m) => `<li>${m}</li>`).join("");
    const techsHtml = course.technologies.join(", ");

    body.innerHTML = `
        <img src="${course.image}" alt="${course.title}">
        <h2 id="modal-title">${course.title}</h2>
        <p><strong>Catégorie :</strong> ${course.category} | <strong>Niveau :</strong> ${course.level}</p>
        <p><strong>Durée :</strong> ${course.duration} | <strong>Prix :</strong> ${course.price} €</p>
        <p><strong>Formateur :</strong> ${course.instructor}</p>
        <p><strong>Note :</strong> ${course.rating}/5 (${course.students} étudiants)</p>
        <p><strong>Technologies :</strong> ${techsHtml}</p>
        <p>${course.description}</p>
        <h3>Modules du cours :</h3>
        <ul>${modulesHtml}</ul>
        <a href="inscription.html" class="btn">S'inscrire maintenant</a>
    `;

    modal.classList.remove("hidden");
}

function setupModal() {
    const modal = document.getElementById("modal");
    const closeBtn = document.getElementById("modal-close");

    closeBtn.addEventListener("click", () => {
        modal.classList.add("hidden");
    });

    modal.addEventListener("click", (event) => {
        if (event.target === modal) {
            modal.classList.add("hidden");
        }
    });

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
            modal.classList.add("hidden");
        }
    });
}

async function loadCoursesInSelect() {
    const select = document.getElementById("course");
    const errorMsg = document.getElementById("form-api-error");

    try {
        const response = await fetch(API_COURSES);
        const data = await response.json();

        data.courses.forEach((course) => {
            const option = document.createElement("option");
            option.value = course.title;
            option.textContent = course.title;
            select.appendChild(option);
        });
    } catch (error) {
        errorMsg.classList.remove("hidden");
    }
}

function setupFormValidation() {
    const form = document.getElementById("registration-form");
    const fields = ["firstname", "lastname", "email", "phone", "course", "level", "motivation"];

    fields.forEach((id) => {
        const input = document.getElementById(id);
        input.addEventListener("input", () => validateInput(id));
        input.addEventListener("change", () => validateInput(id));
    });

    form.addEventListener("submit", (event) => {
        event.preventDefault();
        let isValid = true;

        fields.forEach((id) => {
            if (!validateInput(id)) {
                isValid = false;
            }
        });

        if (isValid) {
            document.getElementById("form-success").classList.remove("hidden");
            form.reset();
            fields.forEach((id) => {
                document.getElementById(id).classList.remove("input-success", "input-error");
            });
        }
    });
}

function validateInput(id) {
    const input = document.getElementById(id);
    const errorSpan = document.getElementById(`${id}-error`);
    const value = input.value.trim();
    let error = "";

    if (id === "firstname" && value.length < 2) {
        error = "Le prénom doit faire au moins 2 caractères.";
    }
    if (id === "lastname" && value.length < 2) {
        error = "Le nom doit faire au moins 2 caractères.";
    }
    if (id === "email") {
        const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regexEmail.test(value)) {
            error = "Format d'email invalide.";
        }
    }
    if (id === "phone") {
        const regexPhone = /^\+[1-9][0-9\s]{7,15}$/;
        if (!regexPhone.test(value)) {
            error = "Format international requis (ex: +33612345678).";
        }
    }
    if (id === "course" && value === "") {
        error = "Veuillez choisir une formation.";
    }
    if (id === "level" && value === "") {
        error = "Veuillez choisir un niveau.";
    }
    if (id === "motivation" && value.length < 50) {
        error = "La motivation doit contenir au moins 50 caractères.";
    }

    if (error !== "") {
        errorSpan.textContent = error;
        input.classList.add("input-error");
        input.classList.remove("input-success");
        return false;
    } else {
        errorSpan.textContent = "";
        input.classList.remove("input-error");
        input.classList.add("input-success");
        return true;
    }
}